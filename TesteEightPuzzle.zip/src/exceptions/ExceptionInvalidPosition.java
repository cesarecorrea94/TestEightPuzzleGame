package exceptions;

public class ExceptionInvalidPosition extends Exception{
	
	public ExceptionInvalidPosition() {
		super();
	}

	public ExceptionInvalidPosition(String msg) {
		super(msg);
	}

}
