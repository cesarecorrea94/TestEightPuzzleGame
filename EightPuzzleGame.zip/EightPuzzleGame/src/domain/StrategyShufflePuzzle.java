package domain;

public interface StrategyShufflePuzzle {
	
	public void shuffle (Puzzle game);

}
